
name = 'Increase spacing between icon and text on infobar buttons'

def run(tweakdir, workingdir, ini):
	ini['Infobar Button Skin']['Spacing'] = '6'
	
	
	