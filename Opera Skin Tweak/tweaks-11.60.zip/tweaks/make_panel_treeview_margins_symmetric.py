
name = 'Make panel treeview margins symmetric'

def run(tweakdir, workingdir, ini):
	ini['Panel Treeview Skin']['Padding Left'] = '2'

	