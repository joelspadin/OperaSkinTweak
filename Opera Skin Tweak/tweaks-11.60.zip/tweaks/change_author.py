
name = 'Change skin author'

def run(tweakdir, workingdir, ini):
	ini['Info']['Author'] = 'Joel Spadin'
	ini['Options']['Fallback foreground'] = '1'
	ini['Options']['Fallback background'] = '1'

	