
name = 'Remove spacing between tabs and top edge'

def run(tweakdir, workingdir, ini):
	ini['Pagebar Button Skin']['Margin Top'] = '0'
	ini['Pagebar Transparent Skin']['Padding Top'] = '0'
	
	
