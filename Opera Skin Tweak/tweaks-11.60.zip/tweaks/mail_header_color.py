
name = 'Mail header flat style'

def run(tweakdir, workingdir, ini):
	ini['Mail Header Toolbar']['Color'] = '#dce1ee'
	ini['Mail Header Toolbar']['Tile Center'] = 'backgrounds/blank.png'

	