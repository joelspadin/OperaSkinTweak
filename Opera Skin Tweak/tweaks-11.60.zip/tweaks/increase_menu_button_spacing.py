
name = 'Increase menu button right margin'

def run(tweakdir, workingdir, ini):
	ini['Pagebar Head Skin']['Padding Right'] = '5'
	
	
	