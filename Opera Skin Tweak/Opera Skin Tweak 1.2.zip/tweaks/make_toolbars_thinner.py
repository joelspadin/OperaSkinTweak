
name = 'Make toolbars thinner'

def run(tweakdir, workingdir, ini):
	ini['Hotlist Selector Skin.left']['Padding Top'] = '29'
	ini['Addressbar Transparent Skin']['Padding Top'] = '2'
	ini['Addressbar Transparent Skin']['Padding Bottom'] = '3'
	ini['Gradient Toolbar Base Skin']['Padding Top'] = '2'
	ini['Gradient Toolbar Base Skin']['Padding Bottom'] = '3'
	ini['Hotlist Panel Header Skin']['Padding Top'] = '2'
	
	
	