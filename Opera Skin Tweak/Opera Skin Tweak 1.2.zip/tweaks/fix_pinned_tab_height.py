
name = 'Fix pinned tab height'

def run(tweakdir, workingdir, ini):
	ini['Pagebar Button Skin']['Padding Top'] = '5'
	ini['Pagebar Button Skin']['Padding Bottom'] = '6'
	
	
