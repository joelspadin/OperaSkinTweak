
name = 'Shift group arrows up 1px'

def run(tweakdir, workingdir, ini):
	ini['Tab Group Button Collapse Skin']['Margin Top'] = '4'
	
	
